function [J, grad] = costFunction(theta, X, y)
%COSTFUNCTION Compute cost and gradient for logistic regression
%   J = COSTFUNCTION(theta, X, y) computes the cost of using theta as the
%   parameter for logistic regression and the gradient of the cost
%   w.r.t. to the parameters.

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

h_theta_x = sigmoid(X * theta);
log_h_theta = log ( h_theta_x );
log_1_h_theta = log ( 1 - h_theta_x );
term = -(y .* log_h_theta) - ( (1-y) .* log_1_h_theta);
J = 1/m * sum(term);

grad = sum ( (h_theta_x - y) .* X ) / m;
end
