function [J, grad] = linearRegCostFunction(X, y, theta, lambda)
%LINEARREGCOSTFUNCTION Compute cost and gradient for regularized linear 
%regression with multiple variables
%   [J, grad] = LINEARREGCOSTFUNCTION(X, y, theta, lambda) computes the 
%   cost of using theta as the parameter for linear regression to fit the 
%   data points in X and y. Returns the cost in J and the gradient in grad

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

h_theta_x = X * theta;
term = (h_theta_x - y) .^2;

% skip theta(1) as we need to not include that
term2 = lambda / (2*m) * sum(theta(2:end, 1) .^ 2);

J = 1/(2*m) * sum(term) + term2;

theta_lambda = (lambda / m) * theta;
% again skip theta(1)
theta_lambda(1) = 0;

grad = (sum ( (h_theta_x - y) .* X ) / m)' + theta_lambda;

end
