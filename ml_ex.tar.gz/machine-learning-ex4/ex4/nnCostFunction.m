function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% You need to return the following variables correctly 
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

yNew = zeros(m, num_labels);
for i=1:m
	yNew(i, y(i)) = 1;
end

% include the bias terms 
X = [ones(m,1) X];

D1 = zeros(hidden_layer_size, input_layer_size+1);
D2 = zeros(num_labels, hidden_layer_size+1);

% forward propagation
a2 = sigmoid(X * Theta1');
% add bias term
a2 = [ones(m,1) a2];
h_theta_x = sigmoid(a2 * Theta2');

% do cost function J calculation
log_h_theta = log ( h_theta_x );
log_1_h_theta = log ( 1 - h_theta_x );
term = -(yNew .* log_h_theta) - ( (1-yNew) .* log_1_h_theta);
term = sum(term, 2);

% do some backprop stuff
z2 = X*Theta1';
delta3 = (h_theta_x - yNew);
delta2 = (delta3*Theta2) ;
% drop bias terms from delta2
delta2 = delta2(:, 2:end);
delta2 = delta2 .* sigmoidGradient(z2);
D1 = (delta2' * X);
D2 = (delta3' * a2);

% skip Theta1 and Theta2s first column as those are the bias terms
regularization = lambda / (2*m) * ( sum(sum(Theta1(:, 2:end).^ 2)) + sum(sum(Theta2(:, 2:end).^2)) );

J = sum(term) / m + regularization;

Theta1(:, 1) = 0;
Theta2(:, 1) = 0;

Theta1_grad = 1/m * D1 + lambda/m * Theta1;
Theta2_grad = 1/m * D2 + lambda/m * Theta2;

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];

end
