function [X_norm, mu, sigma] = featureNormalize(X)
%FEATURENORMALIZE Normalizes the features in X 
%   FEATURENORMALIZE(X) returns a normalized version of X where
%   the mean value of each feature is 0 and the standard deviation
%   is 1. This is often a good preprocessing step to do when
%   working with learning algorithms.

% You need to set these values correctly
mu = zeros(1, size(X, 2));
sigma = zeros(1, size(X, 2));

mu = [mean(X(:,1)) mean(X(:,2))];
sigma = [std(X(:,1)) std(X(:,2))];
X1_norm = (X(:,1) - mu(1)) / sigma(1);
X2_norm = (X(:,2) - mu(2)) / sigma(2);
X_norm = [ X1_norm, X2_norm ];

end
